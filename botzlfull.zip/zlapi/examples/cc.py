style = MultiMsgStyle([
            MessageStyle(offset=0, length=len(menu_message), style="font", size="12", auto_format=False),
            MessageStyle(offset=0, length=len(menu_message), style="bold", auto_format=False)
        ])
        styled_message = Message(text=menu_message, style=style)
        client.replyMessage(styled_message, message_object, thread_id, thread_type, ttl=300000)