import time
import json
import os
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from zlapi.models import Message, ThreadType
import logging

# Cấu hình logging để ghi vào file bot_log.log
logging.basicConfig(
    filename="bot_log.log",  # Đường dẫn và tên file log
    level=logging.DEBUG,  # Mức độ ghi log
    format="%(asctime)s - %(levelname)s - %(message)s"  # Định dạng ghi log
)

# Kết nối với Google Sheets
def connect_to_google_sheet():
    try:
        # Xác thực bằng JSON key file
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        creds = ServiceAccountCredentials.from_json_keyfile_name("modules/cache/credentials.json", scope)
        client = gspread.authorize(creds)
        sheet = client.open_by_url("https://docs.google.com/spreadsheets/d/1yjfFXVNjxd6Gdady8Dk5GugA3W5cB0uXCcu7Ymoi7AE/edit#gid=0").sheet1  # Mở sheet đầu tiên
        logging.info("🔑 Đã kết nối với Google Sheets thành công!")
        return sheet
    except Exception as e:
        logging.error(f"❌ Lỗi khi kết nối Google Sheets: {e}")
        raise

def load_duyetbox_data():
    path = 'modules/cache/duyetboxdata.json'
    if not os.path.exists(path):
        logging.warning("⚠️ File duyetboxdata.json không tồn tại, trả về danh sách rỗng.")
        return []
    with open(path, 'r') as f:
        try:
            data = json.load(f)
            if isinstance(data, list):
                return data
            else:
                logging.warning("⚠️ Dữ liệu không đúng định dạng, trả về danh sách rỗng.")
                return []
        except json.JSONDecodeError as e:
            logging.error(f"❌ Lỗi đọc file duyetboxdata.json: {e}")
            return []

def get_last_ma_gd():
    try:
        if not os.path.exists("last.txt"):
            logging.warning("⚠️ File last.txt không tồn tại, trả về None.")
            return None
        with open("last.txt", "r") as f:
            return f.read().strip()
    except Exception as e:
        logging.error(f"❌ Lỗi khi đọc last.txt: {e}")
        return None

def save_last_ma_gd(ma_gd):
    try:
        with open("last.txt", "w") as f:
            f.write(ma_gd)
            logging.info(f"📄 Đã lưu mã giao dịch {ma_gd} vào file last.txt")
    except Exception as e:
        logging.error(f"❌ Lỗi khi lưu mã giao dịch vào last.txt: {e}")

def gui_zalo(client, thread_id, so_tien, ma_gd):
    msg = Message(text=f"💸 Giao dịch mới!\n• Số tiền: {so_tien} VND\n• Mã GD: {ma_gd}")
    try:
        client.sendMessage(
            message=msg,
            thread_id=thread_id,
            thread_type=ThreadType.GROUP
        )
        logging.info(f"📨 Đã gửi Zalo đến {thread_id}")
    except Exception as e:
        logging.error(f"⚠️ Lỗi gửi Zalo đến {thread_id}: {e}")

# Hàm kiểm tra Google Sheet và gửi thông báo
def batdau_theodoi(client):
    logging.info("🔄 Đang theo dõi giao dịch mới từ Google Sheet...")

    # Kết nối với Google Sheets
    try:
        sheet = connect_to_google_sheet()
    except Exception as e:
        logging.error(f"❌ Lỗi khi kết nối Google Sheets: {e}")
        return

    last_ma_gd = get_last_ma_gd()
    approved_group_ids = load_duyetbox_data()

    while True:
        try:
            # Lấy tất cả bản ghi từ Google Sheets
            data = sheet.get_all_records(head=2)  # Dòng tiêu đề là dòng 2
            if not data:
                logging.warning("⚠️ Không có dữ liệu trong Google Sheets.")
                time.sleep(5)
                continue

            logging.info(f"🔎 Đã lấy {len(data)} bản ghi từ Google Sheets.")

            # Duyệt qua từng giao dịch
            for row in reversed(data):
                try:
                    logging.debug(f"🔍 Đang xử lý giao dịch: {row}")  # Log toàn bộ dữ liệu của mỗi row
                    if row.get('Loại GD') == 'Giao dịch đến' and row.get('Trạng thái') == 'Thành công':
                        ma_gd = row.get('Mã giao dịch')
                        if ma_gd and ma_gd != last_ma_gd:
                            # Lấy thông tin số tiền và kiểm tra
                            so_tien = row.get('Số tiền')
                            if so_tien:
                                logging.info(f"💸 Giao dịch mới: Mã GD {ma_gd}, Số tiền: {so_tien}")
                                # Lưu mã giao dịch mới
                                save_last_ma_gd(ma_gd)

                                # Gửi thông báo tới các nhóm đã duyệt
                                for thread_id in approved_group_ids:
                                    gui_zalo(client, thread_id, so_tien, ma_gd)
                            else:
                                logging.warning(f"⚠️ Không có số tiền trong giao dịch Mã GD {ma_gd}")

                            # Cập nhật mã giao dịch cuối cùng
                            last_ma_gd = ma_gd
                except Exception as e:
                    logging.error(f"❌ Lỗi khi xử lý giao dịch: {e}")

            time.sleep(5)  # Kiểm tra sau mỗi 5 giây
        except Exception as e:
            logging.error(f"❌ Lỗi tổng quát khi theo dõi giao dịch: {e}")
            time.sleep(5)